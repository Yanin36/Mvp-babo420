export default function Home() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-black text-green-400 text-2xl">
      Babo 420 - MVP ระบบสะสมแต้ม & ซอมบี้พร้อมใช้งาน
    </div>
  )
}